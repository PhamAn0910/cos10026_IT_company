<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="description"  content="About Our Group Members">
  <meta name="keywords"     content="HTML5, CSS">
  <meta name="author"       content="Le Ngoc Quynh Trang, Pham Truong Que An">
  <meta name="viewport"     content="width=device-width, initial-scale=1.0">
  
  <title>SonixWave | About us</title>

  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;700&display=swap">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;700&display=swap">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
</head>

<body>
  <!-- Navigation Menu -->
  <?php include 'header.inc'; ?>

  <main>
    <hr>

  <section class="about-us">
    <h1>About Us</h1>   
    <!-- Group Info -->
    <div class="general-info" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
      <dl id="SonixWave">
        <dt>Group Name</dt>
        <dd id="SonixWave-about">SonixWave</dd>
      </dl>
      <p>
        At SonixWave, we blend music and technology to create innovative IT solutions for musicians, producers, and audio enthusiasts. 
        Our mission is to enhance the way people experience sound through cutting-edge digital tools. 
        Whether it's audio software, immersive sound design, or music tech solutions, we're here to push the boundaries of 
        <span id="enhancement6">
          <span id="creativity">creativity</span> and <span id="technology">technology</span>.
        </span>
      </p>

      <dl>
        <dt>Group ID</dt>
        <dd><span>1028 7481 97491</span></dd>
      </dl>

      <dl>
        <dt>Our Tutor</dt>
        <dd>
          <span>Phan Thanh Tra</span> 
          <i class="heart fa fa-heart" id="enhancement4-2"></i>
        </dd>
      </dl>
      <p>
        Mrs. Tra is a dedicated and humorous lecturer who knows exactly how to liven up the classroom. 
        She studied abroad in <i>France</i>, so she's got that extra flair, and she absolutely loves teaching CSS. 
        She has a way of making even the trickiest styling concepts click, all while keeping the class entertained.
      </p>
    </div>

    <section class="member-info">
      <div class="member-card" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
        <figure>
          <img src="images/an.jpg" alt="Photo of Que An">
          <figcaption>Pham Truong Que An</figcaption>
        </figure>
        <p class="member-title">Team Leader</p>
        <dl>
          <dt><strong>Contribution:</strong></dt>
          <dd>CSS Styling &amp; Design</dd>
        </dl>

        <div class="small-divider"></div>
            
        <div class="personal-info">
          <h2>Personal Interests</h2>
            <p>
              <i class="fa-solid fa-film"></i> 
              <strong>Favourite Films:</strong> Hospital Playlist, Reply 1988, Now You See Me, Our Beloved Summer
            </p>
            <p>
              <i class="fa-solid fa-book"></i> 
              <strong>Favourite Books:</strong> Kafka on The Shore, Demian, The Picture of Dorian Gray, Educated
            </p>
            <p>
              <i class="fa-solid fa-headphones"></i> 
              <strong>Favourite Songs:</strong> For Ya, Magic Shop, Twenty Five Twenty One, Luther, Kill Bill
            </p>
        </div>
      </div>

      <div class="member-card" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
        <figure>
          <img src="images/trang.jpg" alt="Photo of Quynh Trang">
          <figcaption>Le Ngoc Quynh Trang</figcaption>
        </figure>
        <p class="member-title">Member</p>
        <dl>
          <dt><strong>Contribution:</strong></dt>
          <dd>HTML &amp; CSS Development</dd>
        </dl>

        <div class="small-divider"></div>
        
        <div class="personal-info">
          <h2>Personal Interests</h2>    
          <p>
            <i class="fa-solid fa-film"></i> 
            <strong>Favourite Films:</strong> Spirited Away, Howl's Moving Castle, My Neighbor Totoro
          </p>
          <p>
            <i class="fa-solid fa-book"></i> 
            <strong>Favourite Books:</strong> Anne of The Green Gables, One Thousand and One Nights
          </p>
          <p>
            <i class="fa-solid fa-headphones"></i> 
            <strong>Favourite Songs:</strong> Always With Me, Demons, Merry-go-round of Life, Carmen
          </p>
        </div>
      </div>
    </section>    

    <section class="timetable" id="enhancement7" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
      <h2>Our Timetable</h2>
      <table>
        <thead>
          <tr>
              <th>Monday</th>
              <th>Tuesday</th>
              <th>Wednesday</th>
              <th>Thursday</th>
              <th>Friday</th>
              <th>Saturday</th>
              <th>Sunday</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <strong>TNE10006 - Networking & Switching</strong><br>
              Lecturer: Mr. Nguyen Vu Anh Quang<br>
              Room: Malaysia
            </td>
            <td>
              <strong>Vovinam - Level 1</strong><br>
              Lecturer: Mr. Nguyen Minh Ky<br>
              Room: Mindfulness Hall
            </td>
            <td>
              <strong>COS10026 - Web Technology Project</strong><br>
              Lecturer: Mrs. Phan Thanh Tra<br>
              Room: Innovation Lab
            </td>
            <td></td>
            <td></td>
            <td>
              <strong>STA10003 - Foundations of Statistics</strong><br>
              Lecturer: Mr. Vo Quoc Trinh<br>
              Room: Innovation Lab
            </td>
            <td></td>
          </tr>
        </tbody>
      </table>
    </section>
    
    <section class="email" data-aos="fade-up" data-aos-duration="800" data-aos-once="true">
      <h2>Our Email</h2>
        <p>Que An's Email: 
          <a href="mailto:105192148@student.swin.edu.au">105192148@student.swin.edu.au</a>
        </p>
        <p>Quynh Trang's Email: 
          <a href="mailto:105028463@student.swin.edu.au">105028463@student.swin.edu.au</a>
        </p>
    </section>
  </section>
  </main>

  <!-- Footer -->
  <?php include 'footer.inc'; ?>

  <script>
    AOS.init();
  </script>

</body>
</html>
