<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="description"  content="IT Company - Career">
  <meta name="keywords"     content="HTML5, CSS">
  <meta name="author"       content="Le Ngoc Quynh Trang, Pham Truong Que An">
  <meta name="viewport"     content="width=device-width, initial-scale=1.0">
  
  <title>SonixWave | Career</title>
  
  <link rel="stylesheet" href="styles/style.css">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=EB+Garamond:wght@400;700&display=swap">
  <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Public+Sans:wght@400;700&display=swap">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
</head>

<body>
  <!-- Navigation Menu -->
  <?php include 'header.inc'; ?>

  <hr id="career-separator-line">

  <div class="jobs-context">
  <!-- Job Listings -->
  <main>
    <h1>Career Opportunities</h1>
    
    <div class="jd" data-aos="fade-up" data-aos-duration="1500" data-aos-once="true">
      <section class="left-grid">
        <h2>Data Analyst</h2>
            <p><strong>Job Reference Number:</strong> DA123</p>
            <p><strong>Position Title:</strong> Data Analyst</p>
            <p><strong>Salary Range:</strong> &dollar;80,000 - &dollar;110,000 per annum</p>
            <!-- &dollar; = dollar sign -->
            <p><strong>Reports to:</strong> Head of Data Science</p>
      </section>

      <section class="right-grid">
        <h3>Job Description</h3>
            <p>SonixWave is seeking a skilled Data Analyst to collect, analyze, 
              and interpret user listening patterns to enhance personalized 
              music recommendations. This role plays a crucial part in increasing 
              user engagement by optimizing song and genre suggestions.</p>

        <h3>Key Responsibilities</h3>
          <ol>
            <li>Analyze large datasets of user listening behaviors to identify 
              trends and patterns.</li>
            <li>Develop and refine algorithms for personalized music recommendations.</li>
            <li>Collaborate with software engineers and product managers to integrate 
              data-driven insights into the platform.</li>
            <li>Conduct A/B testing to measure the effectiveness of recommendation models.</li>
            <li>Prepare and present data-driven reports to stakeholders.</li>
            <li>Ensure data integrity and compliance with privacy regulations.</li>
          </ol>

        <h3>Qualifications</h3>

        <h4>Essential</h4>
          <ul>
            <li>Bachelor&#39;s degree in Data Science, Statistics, 
              Computer Science, or a related field.</li>
            <!-- &#39;  = apostrophe -->
            <li>Proficiency in SQL and Python/R for data analysis.</li>
            <li>Strong experience with data visualization tools 
              (e.g., Tableau, Power BI, Matplotlib).</li>
            <li>Minimum 3 years of experience in data analytics, 
              preferably in a music or media tech company.</li>
            <li>Understanding of machine learning techniques related to 
              recommendation systems.</li>
            <li>Strong analytical and problem-solving skills.</li>
          </ul>

        <h4>Preferable</h4>
          <ul>
            <li>Masters&#39;s degree in a related field.</li>
            <li>Experience with big data technologies such as Hadoop, Spark, 
              or Google BigQuery.</li>
            <li>Familiarity with AI-driven personalization techniques.</li>
            <li>Passion for music and knowledge of different genres.</li>
          </ul>
      </section>
    </div>

    <div class="jd" data-aos="fade-up" data-aos-duration="1500" data-aos-once="true">
      <section class="left-grid">
        <h2>Software Engineer &lpar;Backend&rpar;</h2>
        <!-- &lpar; and &rpar; = left & right parenthesis -->
          <p><strong>Job Reference Number:</strong> CY987</p>
          <p><strong>Position Title:</strong> Software Engineer &lpar;Backend&rpar;</p>
          <p><strong>Salary Range:</strong> &dollar;90,000 - &dollar;130,000 per annum</p>
          <p><strong>Reports to:</strong> Engineering Manager</p>
      </section>

      <section class="right-grid">
        <h3>Job Description</h3>
          <p>
            SonixWave is looking for a talented Backend Software Engineer 
            to develop and maintain the core infrastructure that powers our 
            music recommendation and streaming platform. This role focuses 
            on ensuring seamless data processing and API integrations to 
            provide a smooth user experience.
          </p>

        <h3>Key Responsibilities</h3>
          <ol>
            <li>Design, develop, and maintain scalable backend systems to 
              support high-volume music streaming.</li>
            <li>Build and optimize APIs for real-time music recommendations 
              and user interactions.</li>
            <li>Work closely with data scientists to deploy machine learning 
              models in production.</li>
            <li>Ensure database efficiency, security, and scalability.</li>
            <li>Collaborate with frontend developers to enhance 
              platform responsiveness.</li>
            <li>Troubleshoot and debug backend issues to maintain high 
              system reliability.</li>
          </ol>

        <h3>Qualifications</h3>

        <h4>Essential</h4>
          <ul>
            <li>Bachelor&#39;s degree in Computer Science, Software Engineering, 
              or a related field.</li>
            <!-- &#39; = apostrophe -->
            <li>Proficiency in backend programming languages such as Python, 
              Java, or Node.js.</li>
            <li>Experience with cloud platforms (AWS, GCP, or Azure).</li>
            <li>Minimum 3 years of experience in backend development, 
              preferably in a media streaming company.</li>
            <li>Strong knowledge of RESTful API design and database 
              management (SQL & NoSQL).</li>
            <li>Familiarity with microservices architecture 
              and distributed systems.</li>
          </ul>
      
        <h4>Preferable</h4>
          <ul>
            <li>Master&#39;s degree in a related field.</li>
            <li>Experience with containerization tools like Docker and Kubernetes.</li>
            <li>Understanding of music streaming protocols 
              and audio processing technologies.</li>
            <li>Passion for music technology and innovation.</li>
          </ul>
      </section>
    </div>
  </main>

  <!-- Aside - Sidebar -->
  <aside>
    <h2>Why <br> <span>Join Us?</span></h2>
    <section>
      <p><i>SonixWave offers a dynamic and innovative work environment, competitive 
        salaries, and opportunities for growth in the tech industry.</i></p>
      
      <h3>Employee Benefits</h3>
        <ul>
          <li>Flexible working hours</li>
          <li>Remote work options</li>
          <li>Health and wellness programs</li>
          <li>Professional development and training</li>
        </ul>
    </section>
  </aside>
  </div>

  <!-- Footer -->
  <?php include 'footer.inc'; ?>

<script>
  AOS.init();
</script>

</body>
</html>

