<?php
    $host = "feenix-mariadb.swin.edu.au";
    $user = "s105192148";
    $pwd = "120906";
    $sql_db = "s105192148_db";
?>
